# AI Health Diagnosis Chatbot

**What this project is**
A simple Flask web application that exposes a chatbot-style UI for collecting patient inputs and
predicting risk for **Diabetes** and **Heart Disease** using lightweight scikit-learn models.
This is a demo / educational project and **not** medical advice.

**How it works**
- A frontend chat UI collects user answers (age, gender, BMI, blood pressure, cholesterol, etc.)
- Backend endpoints `/chat` and `/predict` handle conversational replies and model predictions.
- Two models are trained on synthetic data and saved under `models/`.

**Run locally**
1. (Optional) Create virtualenv and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
2. Start the Flask app:
   ```bash
   python app.py
   ```
3. Open http://127.0.0.1:5000 in your browser.

**Files**
- `app.py` - Flask server (loads models, serves UI, handles chat/predict)
- `models/` - saved sklearn models (pickle files)
- `train/train_models.py` - script to train models from synthetic data
- `templates/index.html` - simple chatbot UI
- `static/js/chat.js` - frontend JS for the chat interface

**Disclaimer**
This demo uses synthetic data and simplified models for demonstration only.
Do NOT use these predictions as real medical diagnostics.
